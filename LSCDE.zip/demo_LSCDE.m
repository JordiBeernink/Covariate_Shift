% demo_LSCDE.m
%
% (c) Masashi Sugiyama, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     sugi@cs.titech.ac.jp,     http://sugiyama-www.cs.titech.ac.jp/~sugi/software/LSCDE/

clear all

rand('state',0);
randn('state',0);

dataset=1;
%%%%%%%%%%%%%%%%%%%%%%%%% Generating data
switch dataset
 case {1,2,3} % Artificial data
  ntrain=300;
  xtrain=rand(1,ntrain)*2-1;
  switch dataset
   case 1
    noise=randn(1,ntrain);
   case 2
    dummy=(rand(1,ntrain)>0.5);
    noise=randn(1,ntrain)*(2/3)+(dummy*2-1);
   case 3
    dummy=(rand(1,ntrain)>0.75);
    noise=randn(1,ntrain).*((dummy==0)*1+(dummy==1)/3)+dummy*(3/2);
  end
  ytrain=sinc(2*pi*xtrain)+exp(1-xtrain).*noise/8;
  xtest0=[-0.5 0 0.5];
  ytest0=linspace(-3,3,300);
  axis_limit=[-1 1 -3 3];
 
 case {4,5} % Real data
  switch dataset
   case 4
    ztrain=load('BoneMineralDensity.csv')';
    xtest0=[12 18 24];
    ytest0=linspace(-0.1,0.25,300);
    axis_limit=[8 30.5 -0.1 0.25];
   case 5
    ztrain=load('OldFaithfulGeyser.csv')';
    xtest0=[50 65 80];
    ytest0=linspace(0,6,300);
    axis_limit=[40 100 0 6];
  end
    xtrain=ztrain(1,:);
    ytrain=ztrain(2,:);
    ntrain=length(xtrain);
end

xtest1=repmat(xtest0,length(ytest0),1);
ytest1=repmat(ytest0',1,length(xtest0));
xtest=xtest1(:)';
ytest=ytest1(:)';
ntest=length(xtest);

%normalization
xscale=std(xtrain,0);
yscale=std(ytrain,0);
xmean=mean(xtrain);
ymean=mean(ytrain);
xtrain_normalized=(xtrain-xmean)./repmat(xscale,[1 ntrain]);
ytrain_normalized=(ytrain-ymean)./repmat(yscale,[1 ntrain]);
xtest_normalized=(xtest-xmean)./repmat(xscale,[1 ntest]);
ytest_normalized=(ytest-ymean)./repmat(yscale,[1 ntest]);

%True conditional density for artificial data
switch dataset
 case 1
  ptest=pdf_Gaussian(ytest,sinc(2*pi*xtest),exp(1-xtest)/8);
 case 2
  tmp=exp(1-xtest)/8;
  ptest=pdf_Gaussian(ytest,sinc(2*pi*xtest)-tmp,tmp*2/3)/2 ...
        +pdf_Gaussian(ytest,sinc(2*pi*xtest)+tmp,tmp*2/3)/2;
 case 3
  tmp=exp(1-xtest)/8;
  ptest=pdf_Gaussian(ytest,sinc(2*pi*xtest),tmp)*3/4 ...
        +pdf_Gaussian(ytest,sinc(2*pi*xtest)+tmp*3/2,tmp/3)/4;
end


%%%%%%%%%%%%%%%%%%%%%%%%% Estimating conditional density
ph=LSCDE(xtrain_normalized,ytrain_normalized,...
         xtest_normalized,ytest_normalized);

figure(1)
clf
hold on
set(gca,'FontName','Helvetica')
set(gca,'FontSize',12)
plot(xtrain,ytrain,'ko','LineWidth',1,'MarkerSize',6)
xtest_unique=unique(xtest);
for xtest_index=1:length(xtest_unique)
  x=xtest_unique(xtest_index);

  switch dataset
   case {1,2,3}
    cdf_scale=(xtest0(2)-xtest0(1))*0.8/max(max(ptest(xtest==x)),max(ph(xtest==x)/yscale));
    plot(xtest(xtest==x)+ptest(xtest==x)*cdf_scale,...
         ytest(xtest==x),'b--','LineWidth',2);
   case {4,5}
    cdf_scale=(xtest0(2)-xtest0(1))*0.8/max(ph(xtest==x)/yscale);
  end
  plot(xtest(xtest==x)+ph(xtest==x)*cdf_scale/yscale,...
       ytest(xtest==x),'r-','LineWidth',2);
end

switch dataset
 case {1,2,3}
  legend('Sample','True','Estimated',4)
 case {4}
  legend('Sample','Estimated',1)
 case {5}
  legend('Sample','Estimated',3)
end
title('Conditional Density Estimation')
axis(axis_limit)
xlabel('x')
ylabel('y')
set(gcf,'PaperUnits','centimeters');
set(gcf,'PaperPosition',[0 0 12 9]);
print('-depsc',sprintf('conditional-density%g',dataset))
print('-dpng',sprintf('conditional-density%g',dataset))

