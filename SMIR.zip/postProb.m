function [phat, Yhat] = postProb(XTe, XTr, kerFunc, Beta, lapconst)

c = size(Beta,2);
K = kerFunc(XTr,XTe);
phat = max(K'*Beta,0);
phat = bsxfun(@rdivide, phat+lapconst, sum(phat,2)+c*lapconst); 
[~,Yhat] = max(phat,[],2);

end