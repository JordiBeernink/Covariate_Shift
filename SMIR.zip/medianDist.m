function dist = medianDist(X)

[n d] = size(X);
D2 = sum(bsxfun(@minus,reshape(X,[n,1,d]),reshape(X,[1,n,d])).^2,3);
dist = median(nonzeros(tril(sqrt(D2),-1)));

end

