function plot2dData(X, Y, Title, fid)

myred = [240 32 32]/255;
myblue = [48 96 224]/255;

pos=(Y==1);
neg=(Y==2);
unlab=(Y==0);

figure(fid);
clf;
hold on;

plot(X(unlab,1),X(unlab,2),'k+','MarkerSize',3,'Linewidth',1);
plot(X(pos,1),X(pos,2),'s','Color',myred,'MarkerSize',6,'Linewidth',2); 
plot(X(neg,1),X(neg,2),'o','Color',myblue,'MarkerSize',6,'Linewidth',2);
title(Title);

hold off;
axis equal;

xc = (min(X(:,1))+max(X(:,1)))/2;
yc = (min(X(:,2))+max(X(:,2)))/2;
xl = (max(X(:,1))-min(X(:,1)))*0.55;
yl = xl/1.2;
xlim([xc-xl,xc+xl]);
ylim([yc-yl,yc+yl]);

