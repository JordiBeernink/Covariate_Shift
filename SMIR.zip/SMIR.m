function pHatFunc = SMIR(X, Yc, options)
%
% SMI Regularization.
%
% X should be n-by-d.
% Yc has two possible formats:
%   1. (l-by-1) containing {1,2,..c}
%       Assume the first l rows in X correspond to the labels in Yc. 
%   2. (n-by-1) containing {0,1,2,...c} with 0 denoting 'unlabeled'.
%
% options: Struct value in Matlab. The fields that can be set:
%   kerFunc: kernel function for the empirical kernel map,
%       default is the Gaussian kernel with sigma
%       as one-fifth of the median of all pairwise distances.
%   gamma and lambda: regularization parameters,
%       default of gamma is 1,
%       default of lambda is c*gamma/n+(1e-3).
%   paramNormalize: way to post-process,
%       1 means A would be normalized so that the prior of Y is uniform; 
%       2 means A would be normalized so that the prior of Y is consistent
%           with that estimated from labeled data (default);
%       3 means A would not be normalized.
%
% pHatFunc is the handle of the estimated class-posterior probability.
%

%%%%% Deal with Input %%%%%

if nargin < 3
    options = [];
end

[X, Yc] = smirInputCheck(X, Yc);

c = length(unique(Yc));
if c <= 1
    error('Number of classes should be at least 2.');
end
n = size(X,1);
l = length(Yc);
Y = sparse(1:l, Yc, 1, l, c);

kerFunc = myProcessOptions(options, 'kerFunc', ...
    @(X1,X2)(kernelGaussian(X1,X2,sqrt(2)*medianDist(X)/5)));
gamma = myProcessOptions(options, 'gamma', 1);
lambda = myProcessOptions(options, 'lambda', c*gamma/n+(1e-3));
paramNormalize = myProcessOptions(options, 'paramNormalize', 2);

if lambda <= c*gamma/n
    error('Necessary condition: lambda > c*gamma/n.');
end

% Laplace smoothing constant for smoothing the probability.
lapconst = 1e-8; 

%%%%% Obtain A %%%%%

K = kerFunc(X,X);
Dn12 = sparse(1:n, 1:n, sum(K,1).^(-0.5));
[EV ED] = eig(K);
Kp12 = EV*sparse(1:n, 1:n, real(diag(ED).^0.5))*EV';
Kn12 = EV*sparse(1:n, 1:n, real(diag(ED).^(-0.5)))*EV';
Kp12B = Kp12(:, 1:l);

T = Dn12*Kp12B;
Q = n*(T*T') + lambda*n*l*eye(n) - gamma*l*c*Dn12*K*Dn12;
A = Q \ (n*T*Y);
 
%%%%% Post-process A %%%%%

if paramNormalize == 1
    Beta = bsxfun(@rdivide, (n/c)*Kn12*Dn12*A, sum(Kp12*Dn12*A,1));
elseif paramNormalize ==2
    Pi = sum(Y,1)/l;
    Beta = bsxfun(@rdivide, n*Kn12*Dn12*A*diag(Pi), sum(Kp12*Dn12*A,1));
elseif paramNormalize == 3
    Beta = Kn12*Dn12*A;
end

%%%%%  Deal with Output %%%%%

pHatFunc = @(XTe)(postProb(XTe, X, kerFunc, Beta, lapconst));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

function [X, Yc] = smirInputCheck(Xi, Yci)
%
% Check input X (n-by-d) and Y (l-by-1 or n-by-1) to be given to SMIR.
%
% Yc has two possible formats:
% 1. (l-by-1) containing {1,2,..c};
% 2. (n-by-1) containing {0,1,2,...c} with 0 denoting 'unlabeled'.
% 

[yr yc] = size(Yci);
xr = size(Xi,1);

if yc > 1
    error('Label vector should be a column vector.');
end

if yr < xr 
    % Assume format 1.
    if any(~Yci)
        error('Label vector should not contain 0 in format 1.');
    end
    X = Xi;
    Yc = Yci;
elseif yr == xr
    % Assume format 2.
    I = logical(Yci);
    Yc = Yci(I);
    X = [Xi(I,:);Xi(~I,:)];
else
    error('Number of labels should not be larger than data points.');
end

end
