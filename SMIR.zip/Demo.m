clear
clc

load 2moons

y(y==-1) = 2;

ind = [2,4];
yy = zeros(length(y),1);
yy(ind) = y(ind);

plot2dData(x,yy,'Training Data',101);

c = 2;
n = size(x,1);

options = [];
options.kerFunc = @(X1,X2)(kernelGaussian(X1,X2,sqrt(2)*medianDist(x)/15));
pHatFunc = SMIR(x,yy,options);

[~,Yhat] = pHatFunc(x);
plot2dData(x,Yhat,'Classification of Training Data',102);

[~,Yhat] = pHatFunc(xt);
plot2dData(xt,Yhat,'Classification of Test Data',103);

plot2dBoundary(x,pHatFunc,'Decision Boundary of Estimated Class-posterior Probability',104);
plot2dEntropy(x,pHatFunc,'Entropy of Estimated Class-posterior Probability',105);
