function plot2dEntropy(X, pHatFunc, Title, fid)
%
% Plot the entropy of the estimated class-posterior probability.
%

steps = 500;

xc = (min(X(:,1))+max(X(:,1)))/2;
yc = (min(X(:,2))+max(X(:,2)))/2;
xl = (max(X(:,1))-min(X(:,1)))*0.55;
yl = xl/1.2;

xlist = linspace(xc-xl,xc+xl,steps);
ylist = linspace(yc-yl,yc+yl,steps);
[xx yy] = meshgrid(xlist, ylist);
phat = pHatFunc([xx(:),yy(:)]);

E = -nansum(phat.*log2(phat),2);
ee = reshape(E,length(ylist),length(xlist));
ee = ee(length(ylist):-1:1,:);

figure(fid);
clf;

imagesc(xlist,ylist,ee);
colorbar;
colormap jet;
title(Title);

axis off;
axis equal;

end