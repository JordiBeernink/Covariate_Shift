function plot2dBoundary(X, pHatFunc, Title, fid)
%
% Plot the decision boundary of the estimated class-posterior probability.
%

myred = [240 32 32]/255;
myblue = [48 96 224]/255;

steps = 500;

xc = (min(X(:,1))+max(X(:,1)))/2;
yc = (min(X(:,2))+max(X(:,2)))/2;
xl = (max(X(:,1))-min(X(:,1)))*0.55;
yl = xl/1.2;

xlist = linspace(xc-xl,xc+xl,steps);
ylist = linspace(yc-yl,yc+yl,steps);
[xx yy] = meshgrid(xlist, ylist);
[~,Yhat] = pHatFunc([xx(:),yy(:)]);

figure(fid);
clf;
hold on;

zz = reshape(Yhat,length(ylist),length(xlist));
contourf(xx,yy,zz);
colormap([myred;myblue]);
title(Title);

hold off;
axis off;
axis equal;

end