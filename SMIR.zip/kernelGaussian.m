function K = kernelGaussian(X1, X2, sigma)

[n1 d1] = size(X1);
[n2 d2] = size(X2);
if d1==d2
    D2 = sum(bsxfun(@minus,reshape(X1,[n1,1,d1]),reshape(X2,[1,n2,d2])).^2,3);
    K = exp(-D2./(sigma^2));
else
    K = NaN;
end

end