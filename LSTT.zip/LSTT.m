function [pvalue,PE0,PE]=LSTT(x1,x2,T)
%
% Least-Squares Two-Sample Test
%
% Test the null hypothesis that x1 and x2 are drawn from the same distribution.
%
% Usage:
%       [pvalue,PE0,PE]=LSTT(x,y,T)
%
% Input:
%    x1         : d by n sample matrix
%    x2         : d by n sample matrix
%    T          : Number of repetitions for permutation test (default: T=100)
%
% Output:
%    pvalue : pvalue
%    PE0    : Estimate of Pearson divergence for original data
%    PE     : Estimates of Pearson divergence for randomly shuffuled data
%
% (c) Masashi Sugiyama, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     sugi@cs.titech.ac.jp,

  if nargin<3
    T=100; % Number of repetitions for permutation test
  end

  d =size(x1,1);
  dd=size(x2,1);
  if d ~= dd
    error('x1 and x2 must have the same dimensionality!!!')
  end;

  n1=size(x1,2);
  n2=size(x2,2);
  x=[x1 x2];

  tmp=repmat(sum(x.^2,1),[n1+n2 1]);
  dist2=tmp+tmp'-2*x'*x;
  width_list=sqrt(median(dist2(:)))*[0.6 0.8 1 1.2 1.4];
  lambda_list=10.^[-3 -2 -1 0 1];
disp('Computing Pearson divergence for original data')
  [wh_x1,wh_x2]=uLSIF(x1,x2,width_list,lambda_list,n1,5);
  PE0=mean(wh_x1)/2-mean(wh_x2)+1/2;
  for t=1:T %permutation test
disp(sprintf('  Computing Pearson divergence for permuted data (%g/%g)',t,T))
    rand('state',t);
    randn('state',t);
    xt=x(:,randperm(n1+n2));
    x1t=xt(:,1:n1);
    x2t=xt(:,n1+1:n1+n2);
    [wh_x1t,wh_x2t]=uLSIF(x1t,x2t,width_list,lambda_list,n1,5);
    PE(t)=mean(wh_x1t)/2-mean(wh_x2t)+1/2;
  end
  
  pvalue=mean(PE>PE0);
