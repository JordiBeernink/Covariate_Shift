clear all;

n=300;
dataset=1;
switch dataset
 case 1 % (mu,sigma)=(0,1)
  mu=0;
  sigma=1;
 case 2 % (mu,sigma)=(0,0.7)
  mu=0;
  sigma=0.7;
 case 3 % (mu,sigma)=(0,1.3)
  mu=0;
  sigma=1.3;
 case 4 % (mu,sigma)=(0.3,1)
  mu=0.3;
  sigma=1;
end

rand('state',1);
randn('state',1);
X1=randn(1,n);
X2=randn(1,n)*sigma+mu;

%[pvalue,PE0,PE]=LSTT(X1,X2);

disp('Plain')
[pvalue_1,PE0_1,PE_1]=LSTT(X1,X2);
disp('Reciprocal')
[pvalue_2,PE0_2,PE_2]=LSTT(X2,X1);
if pvalue_1<pvalue_2
  pvalue=pvalue_1;
  PE0=PE0_1;
  PE=PE_1;
else
  pvalue=pvalue_2;
  PE0=PE0_2;
  PE=PE_2;
end

figure(1); clf; hold on
set(gca,'FontSize',10)
subplot(2,1,1); hold on
title(sprintf('Data Set 1 (\\mu=%g, \\sigma=%g)',0,1))
hist(X1,[-4:0.25:4])
h = findobj(gca,'Type','patch'); set(h,'FaceColor','g')
legend('x1')
subplot(2,1,2); hold on
title(sprintf('Data Set 2 (\\mu=%g, \\sigma=%g)',mu,sigma))
hist(X2,[-4:0.25:4])
h = findobj(gca,'Type','patch'); set(h,'FaceColor','r')
legend('x2')
xlabel('x')
set(gcf,'PaperUnits','centimeters');
set(gcf,'PaperPosition',[0 0 8 8]);
print('-dpng',sprintf('LSTT-data-mu%g-sigma%g.png',mu,sigma))

figure(2); clf; hold on
set(gca,'FontSize',10)
hist(PE,[-0.02:0.01:0.63])
h = findobj(gca,'Type','patch'); set(h,'FaceColor','y')
plot(PE0,0,'rx','Linewidth',4,'MarkerSize',20)
title(sprintf('P-value = %0.2f',pvalue))
xlabel('Pearson Divergence')
axis([-0.02 0.63 0 inf])
set(gcf,'PaperUnits','centimeters');
set(gcf,'PaperPosition',[0 0 8 4]);
print('-dpng',sprintf('LSTT-PE-mu%g-sigma%g.png',mu,sigma))

