function [yh,ph]=LSPC_test(xtest,xce,LSPC_model,sigma)
%
% Predict labels
% by Importance Weighted Least-Squares Probabilistic Classifier (IWLSPC)
%
% Usage:
% [yh,ph]=LSPC_test(xtest,xce,LSPC_model,sigma)
%
% Input:
%    xtest            
%     -xtest(c).data:   test samples with label c
%    xce
%     -xce.data:        kernel centers
%    sigma:             width of Gaussian kernel
%
% Output:
%    yh:                predicted labeles
%    ph:                class posterior probabilities
%
% (c) Hirotaka Hachiya
%     Department of Compter Science, Tokyo Institute of Technology, Japan.
%     hachiya@cs.titech.ac.jp,
%     http://sugiyama-www.cs.titech.ac.jp/~hachiya/software/IWLSPC/
%

c=size(LSPC_model,2);   % Number of classes
nt=size(xtest,2);  % Number of test samples
ph=zeros(c,nt);         % Class-posterior probabilities

for y=1:c          
    Ky=kernel_Gaussian(xce.data,xtest,sigma);
    ph(y,:)=LSPC_model(y).alpha'*Ky;
end % for y
ph=max(ph,0.00000001);
ph=ph./repmat(sum(ph,1),[c 1]); % Normalization
[ph_max,yh]=max(ph); % Choose most probable class
