function [sigma_chosen,lambda_chosen,flat_chosen]=LSPC_IWCV(xtrain,xce,xscale)
%
% Importance Weighted Cross Validation for selecting hyper-parameters of
% Importance Weighted Least-Squares Probabilistic Classifier (IWLSPC)
%
% Usage:
% [sigma_chosen, lambda_chosen,flat_chosen]=LSPC_IWCV(xtrain,xce,xscale)
%
% Input:
%    xtrain            
%     -xtrain(c).data:  training samples with label c
%     -xtrain(c).iw:    importance weights for samples with label c
%     -xtrain(c).n:     the number of samples with label c
%    xce
%     -xce.data:        kernel centers
%    xscale:            (OPTIONAL) central candidate of sigma
%
% Output:
%    sigma_chosen:      width of Gaussian kernel, chosen by IWCV
%    lambda_chosen:     regularization parameter, chosen by IWCV
%    flat_chosen:       flattening parameter, chosen by IWCV
%
% (c) Hirotaka Hachiya
%     Department of Compter Science, Tokyo Institute of Technology, Japan.
%     hachiya@cs.titech.ac.jp,
%     http://sugiyama-www.cs.titech.ac.jp/~hachiya/software/IWLSPC/
%
if(~exist('xscale'))
	xscale=1;
end

sigma_list=xscale*[1/10 1/5 1/2 1 2 3]; % Candidates of Gaussian width
lambda_list=logspace(-1,0,5); % Candidates of regularization parameter
flat_list=[0:0.2:1]; % Candidates of flattening parameter

c=length(xtrain);
score_cv=zeros(length(flat_list),length(sigma_list),length(lambda_list));
fold_cv=5;

for y=1:c
    tmp=floor([0:xtrain(y).n-1]*fold_cv./xtrain(y).n)+1;
    xtrain(y).cv_index=tmp(randperm(xtrain(y).n));
end % for y

for sigma_index=1:length(sigma_list)
    sigma=sigma_list(sigma_index);

    K = kernel_Gaussian(xce.data,[xtrain(:).data],sigma);
    for y=1:c        
        Ky{y} = kernel_Gaussian(xce.data,xtrain(y).data,sigma);
	end % for y

    for lambda_index=1:length(lambda_list)
        lambda=lambda_list(lambda_index);

        for flat_index=1:length(flat_list)
            flat=flat_list(flat_index);

            score_tmp=zeros(1,fold_cv);
            for k=1:fold_cv
                ph=[];
                for y=1:c
                    %=========================
                    % training
                    Kcv=K(:,[xtrain(:).cv_index]~=k);
                    Kycv=Ky{y}(:,[xtrain(y).cv_index]~=k);

                    iwcv=[xtrain(:).iw];
                    iwcv=iwcv([xtrain(:).cv_index]~=k);
                    iwycv=[xtrain(y).iw];
                    iwycv=iwycv(xtrain(y).cv_index~=k);       
                    n=sum([xtrain(:).cv_index]~=k);

                    Q = Kcv*diag(iwcv.^flat)*Kcv'/n;
                    q = sum(Kycv*diag(iwycv.^flat),2)/n;
                    alphah=mylinsolve(Q+lambda*eye(xce.n),q);
                    %=========================

                    %=========================
                    % validation
                    for yy=1:c
                        tmp=Ky{yy}(:,xtrain(yy).cv_index==k);
                        test_cv(yy).ph=alphah' * tmp;
                    end

                    test_cv(y).label=y*ones(1,sum(xtrain(y).cv_index==k));
                    test_cv(y).iw = xtrain(y).iw(xtrain(y).cv_index==k);
                    ph(y,:)=[test_cv(:).ph];
                    %=========================
                end % for y

                %=========================
                % Score
                ph=max(ph,0);
                ph=ph./repmat(sum(ph,1),[c 1]);
                [ph_max,yh]=max(ph);

                yh(yh==1)=-1;
                yh(yh==2)=1;
                pre=[test_cv(:).label];
                pre(pre==1)=-1;
                pre(pre==2)=1;
                score_tmp(k)=(1-sin(yh.*pre))*[test_cv(:).iw]'/length(yh);
                %=========================
                
            end % for k
            score_cv(flat_index,sigma_index,lambda_index)=mean(score_tmp);
        end % for flat_index
    end % for lambda_index
end % for sigma_index

[score_cv_tmp,lambda_chosen_index]=min(score_cv,[],3);
[score_cv_tmp,sigma_chosen_index]=min(score_cv_tmp,[],2);
[score,flat_chosen_index]=min(score_cv_tmp);
lambda_chosen=lambda_list(lambda_chosen_index(flat_chosen_index,sigma_chosen_index(flat_chosen_index)));
sigma_chosen=sigma_list(sigma_chosen_index(flat_chosen_index));
flat_chosen=flat_list(flat_chosen_index);
