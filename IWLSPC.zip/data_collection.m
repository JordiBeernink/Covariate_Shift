function [tr te]=data_collection(ntr,nte)
%
% Collecting training and test samples
%
% Usage:
% [tr te]=data_collection(ntr,nte)
%
% Input:
%    ntr:       number of training samples
%    nte:       number of test samples
%
% Output:
%    tr:        training samples
%    te:        test samples
%
% (c) Hirotaka Hachiya
%     Department of Compter Science, Tokyo Institute of Technology, Japan.
%     hachiya@cs.titech.ac.jp,
%     http://sugiyama-www.cs.titech.ac.jp/~hachiya/software/IWLSPC/
%


    % trainning data
    tr(1).n = 0;
    tr(2).n = 0;
    for i=1:ntr
        mix_id = floor(rand*2)+1;
        if(mix_id == 1)
            x = mgd(1,2,[2,3]',[1,0;0,2]); % res2
        else
            x = mgd(1,2,[-2,3]',[1,0;0,2]); % res2
        end
        
        % class posterior
        pr = (1+tanh(x(1)+min(0,x(2))))/2;
        
        if(pr>0.5)
            tr(1).data(:,tr(1).n+1) = x;
            tr(1).n = tr(1).n+1;
        else
            tr(2).data(:,tr(2).n+1) = x;
            tr(2).n = tr(2).n+1;
        end
    end
    
    tr(1).n = size(tr(1).data,2);
    tr(2).n = size(tr(2).data,2);

    % test data
    te(1).n = 0;
    te(2).n = 0;
    for i=1:nte
        mix_id = floor(rand*2)+1;
        if(mix_id == 1)
            x = mgd(1,2,[3,-1]',[1,0;0,1]);
        else
            x = mgd(1,2,[0,-1]',[1,0;0,1]);
        end
        
        % class posterior
        pr = (1+tanh(x(1)+min(0,x(2))))/2;
        
        if(pr>0.5)
            te(1).data(:,te(1).n+1) = x;
            te(1).n = te(1).n+1;
        else
            te(2).data(:,te(2).n+1) = x;
            te(2).n = te(2).n+1;
        end
    end
    te(1).n = size(te(1).data,2);
    te(2).n = size(te(2).data,2);
