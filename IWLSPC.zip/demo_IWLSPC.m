% (c) Hirotaka Hachiya, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     hachiya@cs.titech.ac.jp,
%     http://sugiyama-www.cs.titech.ac.jp/~hachiya/software/LSPC/
ntr = 2000;	% # of training data
nte = 1000; % # of test data
niwbasis=200;

% collect test training data
[tr te]=data_collection(ntr,nte);

%======================
% Pre-processing (normalized, whitening)
dataall = [tr(:).data te(:).data];               % normalization by only test data
dmean = mean(dataall,2);
dstd=std(dataall,0,2);

trainft_normalized(1).data = (tr(1).data - repmat(dmean,1,tr(1).n))./repmat(dstd,1,tr(1).n);
trainft_normalized(2).data = (tr(2).data - repmat(dmean,1,tr(2).n))./repmat(dstd,1,tr(2).n);    
trainft_normalized(1).n = tr(1).n;
trainft_normalized(2).n = tr(2).n;
    
testft_normalized(1).data = (te(1).data - repmat(dmean,1,te(1).n))./repmat(dstd,1,te(1).n);
testft_normalized(2).data = (te(2).data - repmat(dmean,1,te(2).n))./repmat(dstd,1,te(2).n);
%======================

%======================
% Kernel Center
nc = size(trainft_normalized,2);        
rand_index=randperm(nte);
testfall_normalizeddata = [testft_normalized(:).data];
xce.data = testfall_normalizeddata(:,rand_index(1:niwbasis));
xce.n = size(xce.data,2);            
%======================

%======================
% labels
trainlabel = [ones(size(trainft_normalized(1).data,2),1); ones(size(trainft_normalized(2).data,2),1)*2];        

% test label
testlabel = [ones(size(testft_normalized(1).data,2),1); ones(size(testft_normalized(2).data,2),1)*2];
%======================

%======================
% Estimate importance weights

% central candidate of Kernel width
all_normalized=[trainft_normalized(:).data testft_normalized(:).data];
tmp=repmat(sum(all_normalized.^2,1),[length(all_normalized) 1]);
dist=tmp+tmp'-2*all_normalized'*all_normalized;        
fscale=sqrt(median(dist(:)));

addpath('uLSIF');
sigma_list=fscale*[1/10 1/5 1/2 1 2 3]; % Candidates of Gaussian width
[iw] = uLSIF([trainft_normalized(:).data],[testft_normalized(:).data],[],sigma_list,[],xce.n,5);
trainft_normalized(1).iw = iw(1:trainft_normalized(1).n);                
trainft_normalized(2).iw = iw(trainft_normalized(1).n+1:end);
%======================

%##############################
% LSPC 
%##############################

%======================    
% model selection by IWCV
[sigma_chosen,lambda_chosen] = LSPC_CV(trainft_normalized,xce,fscale);
fprintf('sigma=%.2f lambda=%.2f\n',sigma_chosen,lambda_chosen);
%======================
    
%======================
% training
t=cputime;
model = LSPC_trainIW(trainft_normalized,xce,sigma_chosen,lambda_chosen,0);
ctime=cputime-t;
%======================
    
%======================
% test
[ytest,class_posterior] = LSPC_test([testft_normalized(:).data],xce,model,sigma_chosen);   
%======================
    
%======================
% compute success rate
success_rate=mean(ytest==testlabel');
%======================

fprintf(1,'LSPC, success rate=%.2f computation time=%.2f\n',success_rate,ctime);
%##############################
%##############################

%##############################
% IWLSPC 
%##############################

%======================    
% model selection by IWCV
[sigma_chosenIW,lambda_chosenIW,flat_chosenIW] = LSPC_IWCV(trainft_normalized,xce,fscale);
fprintf('sigma=%.2f lambda=%.2f flat=%.2f\n',sigma_chosenIW,lambda_chosenIW,flat_chosenIW);
%======================
    
%======================
% training
t=cputime;
model = LSPC_trainIW(trainft_normalized,xce,sigma_chosenIW,lambda_chosenIW,flat_chosenIW);
ctimeIW=cputime-t;
%======================
    
%======================
% test
[ytest_IW,class_posterior_IW] = LSPC_test([testft_normalized(:).data],xce,model,sigma_chosenIW);   
%======================
    
%======================
% compute success rate
success_rateIW=mean(ytest_IW==testlabel');
%======================

fprintf(1,'IWLSPC, success rate=%.2f computation time=%.2f\n',success_rateIW,ctimeIW);
%##############################
%##############################

%======================
% plot
% training and test labels
figure(1)
clf
hold on
plot(trainft_normalized(1).data(1,:),trainft_normalized(1).data(2,:),'om')        
plot(trainft_normalized(2).data(1,:),trainft_normalized(2).data(2,:),'oc')
plot(testft_normalized(1).data(1,:),testft_normalized(1).data(2,:),'or')    
plot(testft_normalized(2).data(1,:),testft_normalized(2).data(2,:),'ob')    
g=legend('train positive','train negative','test positive','test negative'); 
set(g,'FontSize',15)
saveas(1,'test.png');

% training predicted test labels by LSPC
figure(2)
clf
hold on
plot(trainft_normalized(1).data(1,:),trainft_normalized(1).data(2,:),'om')        
plot(trainft_normalized(2).data(1,:),trainft_normalized(2).data(2,:),'oc')
plot(testfall_normalizeddata(1,ytest==1),testfall_normalizeddata(2,ytest==1),'or')
plot(testfall_normalizeddata(1,ytest==2),testfall_normalizeddata(2,ytest==2),'ob')
g=legend('train positive','train negative','test positive predicted by LSPC','test negative predicted by LSPC');    
set(g,'FontSize',15)
saveas(2,'LSPCpredict.png');

% training predicted test labels by LSPC
figure(3)
clf
hold on
plot(trainft_normalized(1).data(1,:),trainft_normalized(1).data(2,:),'om')        
plot(trainft_normalized(2).data(1,:),trainft_normalized(2).data(2,:),'oc')
plot(testfall_normalizeddata(1,ytest_IW==1),testfall_normalizeddata(2,ytest_IW==1),'or')
plot(testfall_normalizeddata(1,ytest_IW==2),testfall_normalizeddata(2,ytest_IW==2),'ob')
g=legend('train positive','train negative','test positive predicted by IWLSPC','test negative predicted by IWLSPC');    
set(g,'FontSize',15)
saveas(3,'IWLSPCpredict.png');
%======================
