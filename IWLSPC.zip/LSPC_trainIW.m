function LSPC_model=LSPC_trainIW(xtrain,xce,sigma,lambda,flat)
%
% Learning class-posteriors
% by Importance Weighted Least-Squares Probabilistic Classifier (IWLSPC)
%
% Usage:
% LSPC_model=LSPC_train(xtrain,xce,sigma,lambda,flat)
%
% Input:
%    xtrain            
%     -xtrain(c).data:  training samples with label c
%     -xtrain(c).iw:    importance weights for samples with label c
%    xce
%     -xce.data:        kernel centers
%    sigma:             width of Gaussian kernel
%    lambda:            regularization parameter
%    flat:              (OPTIONAL) flattening parameter
%
% Output:
%    LSPC_model:        learned parameters
%
% (c) Hirotaka Hachiya
%     Department of Compter Science, Tokyo Institute of Technology, Japan.
%     hachiya@cs.titech.ac.jp,
%     http://sugiyama-www.cs.titech.ac.jp/~hachiya/software/IWLSPC/
%

if(~exist('flat'))
  flat = 1;
end

c=length(xtrain); % Number of classes
n=size([xtrain(:).data],2); % Number of training samples

K=kernel_Gaussian(xce.data,[xtrain(:).data],sigma);  
Q = (K*diag([xtrain(:).iw].^flat)*K')/n;

for y=1:c
    Ky=kernel_Gaussian(xce.data,[xtrain(y).data],sigma);
    q = sum(Ky*diag([xtrain(y).iw].^flat),2)/n;
    LSPC_model(y).alpha=mylinsolve(Q+lambda*eye(xce.n),q);
end % for y
